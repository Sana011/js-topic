// operater 
// Arithmetic Operators
// Assignment Operators
// Comparison Operators
// Logical Operators
// Conditional Operators
// Type Operators










// logical operator && || not 
//  arthemetic operator + - * ?
// let x =10;
// let y=5;
// console.log(x+y)
// let a =10;
// let b=5;
// console.log(a-b)

// let c =10;
// let d=5;
// console.log(c*d)

// let e =10;
// let f=5;
// console.log(e/f)


//  conditional opertaor < == > <= >= ===
// let k =6
// let l= 9;
// if(k==l){
//     console.log(true)
// }
// else{
//     console.log(false)
// }
// let o =6
// let p= 9;
// if(o==p){
//     console.log(true)
// }
// else{
//     console.log(false)
// }

// assignmnt operator

// Operator	Example	Same As
// =	   x = y	  x = y
// +=	   x += y	  x = x + y
// -=	   x -= y	  x = x - y
// *=	   x *= y	  x = x * y
// /=	   x /= y	  x = x / y
// %=      x %= y	  x = x % y
// **=	   x **= y    x = x ** y
//  let s=50;
//  let m=50;
//  res = s += m
//  console.log(res)

// JavaScript Comparison Operators

// Operator	Description
// ==	equal to sirf value xhexk krta hai 
// ===	equal value and equal type also chexk data type
// !=	not equal
// !==	not equal value or not equal type
// >	greater than
// <	less than
// >=	greater than or equal to
// <=	less than or equal to
// ?	ternary operator
// ==
// let valu1=5;
// let value2=5;
// if (valu1==value2) {
//     console.log(true);
// } else {
//     console.log(false);  
// }


// ===
// let valu3=5;
// let value4="5";
// if (valu3===value4) {
//     console.log(true);
// } else {
//     console.log(false);  
// }