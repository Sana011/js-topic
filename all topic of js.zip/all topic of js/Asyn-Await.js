// Async Await 
// Async main hum asyncrnous programming use krain gyh yani sb task simaltenously chlty rhen gyh
// async and await make promises easier to write" uselly use in api calling
// synchronously which means code is executed line by line
// async can be done in parallel
// async makes a function return a Promise
// await makes a function wait for a Promise

// The keyword async before a function makes the function return a promise:

// async is keyword which denotes aysynchrnys
async function myFunction() {
  return "Hello";
}
myFunction()