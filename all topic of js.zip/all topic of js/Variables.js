// variables in js 
var x;
var y;
var x =100;
var y =200;
console.log(x+y);