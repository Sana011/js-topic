// In JavaScript, almost "everything" is an object.
// <!-- object are key value pair data structure
// storing variable and function togather in a cntainer -->
// agar ksi key m value ki jaaga hum koi funcrion pass krty hai n to osy object method kty hn yani os object ka method
// Booleans can be objects (if defined with the new keyword)
// Numbers can be objects (if defined with the new keyword)
// Strings can be objects (if defined with the new keyword)
// Dates are always objects
// Maths are always objects
// Regular expressions are always objects
// Arrays are always objects
// Functions are always objects
// Objects are always objects



// There are different ways to create new objects:

// Create a single object, using an object literal.
// An object literal is a list of name:value pairs (like age:50) inside curly braces {}.
// const person = {firstName:"John", lastName:"Doe", age:50, eyeColor:"blue"};
// // Create a single object, with the keyword new.
// const person = new Object();
// person.firstName = "John";
// person.lastName = "Doe";
// person.age = 50;
// person.eyeColor = "blue";
// Define an object constructor, and then create objects of the constructed type.
// Create an object using Object.create().

// Objects are mutable: They are addressed by reference, not by value.