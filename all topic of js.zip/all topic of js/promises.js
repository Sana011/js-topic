
// A promise is an object and is something that is done/completed in the future.
// three condition are 
// resolve 
// Rejection
// pending

// syntax
// var myPromise = new Promise(function(resolve, reject){
//     // some code
//   });
//   romise constructor only accepts the callback function as an argument
//  The resolve and reject parameters are used in the callback function,

// creating Promise object
var myPromise = new Promise(function(resolve, reject) {
    const number1 = 2;
    const number2 = 2;
    // comparing two numbers
    if(number1 === number2) {
     console.log("fullfiled")
      resolve();
    } else {
        console.log("Rejected")
      reject();
    }
});


//  promise consumers that are then() method(if promise fulfilled) and catch() method (if promise is rejected).

