// Callbacks are functions that are passed inside the arguments of other functions

// functions are objects and objects can be passed as arguments to functions.
// function demoFunction(callback){
//     callback();
// }

// demoFunction is function in its round brkets another fun is passed

// function job1() {
//     console.log("I am task 1");
//   }
//   function job3() {
//     console.log("I am task 3");
//   }
//   function job2() {
//     console.log("I am task 2");
//   }
  
  
//   job1();
//   job2();
//   job3();

//   func job 1 job 2 job 3 sary ak sath invoke hongyh lykin agar ase condtion ho jis m task ki completion k bad task 2 show ho to hmen callback or asyn chaye hoga

// JavaScript
// Callbacks and Promises | Explained with Examples
// 11 months agoby Shehroz Azam
// JavaScript is a high-level programming language that executes synchronously which means code is executed line by line. The next lines of code cannot execute once the previous line of code is fully executed. However, we can also implement asynchronous code in which some block of code can be executed along with the original code thread so that execution of the code can be done in parallel. To implement asynchronous code we use callbacks and promises in JavaScript.
// In this post, we will see what are callbacks and promises in JavaScript explained with the help of examples.

// What are callbacks?
// Callbacks are functions that are passed inside the arguments of other functions, this procedure is valid in JavaScript because functions are objects and objects can be passed as arguments to functions. The basic structure of the callback function looks something like this.

// MY LATEST VIDEOS
// function demoFunction(callback){
//     callback();
// }
// Execution sequence and need for callbacks
// Callbacks functions are used to acquire control over the sequence of execution. Generally, functions are executed on the basis of the sequence that they are invoked, not on the sequence in which they are defined. For example:

// function job1() {
//   console.log("I am task 1");
// }
// function job3() {
//   console.log("I am task 3");
// }
// function job2() {
//   console.log("I am task 2");
// }


// job1();
// job2();
// job3();
// You would get the following output:


// But what if we want to invoke task 2 only when task 1 finishes its processing. For that, we need callback functions and some basic understanding of asynchronous execution.