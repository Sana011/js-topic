// JavaScript defines 7 types of primitive data types:

// Examples
// string
// number
// boolean
// null
// undefined
// symbol
// bigint
// A primitive value is a value that has no properties or methods.

// 3.14 is a primitive value

// A primitive data type is data that has a primitive value.

// Immutable
// Primitive values are immutable (they are hardcoded and cannot be changed).