//  function to perform specific task
// removes the need for code repetition. This is known as modular coding.

// Types of function
//1 Function Expression
//2 Anonymous Functions
//3 Immediately Invoked Function Expression
//4 Constructor Functions
//5 Getter Functions
//6 Hoisting
//7 Arrow Functions

// These are named function 
// function myFirstFunc(){
//     let a =2;
//     let b =20;
//     sum =(a*b)
//     console.log(sum)
// }

// // fun will be excecuted when calls or invokes that func
// myFirstFunc()

// fun withreturn
//The function will stop executing on return statement, 
// fun with para & argument
// function myFunction(p1, p2) {
//     return p1 / p2;
   
//   }

//  x = myFunction(44,79)
//  console.log(x)


// //  Function Expression
// // in this the whole fun is assinged to a var is called fun experesion & the func is called by varible name 
// // it uses a variable to express the name of the function
// var lifeRel = function myFun() {
//     console.log("The life is Full of going On");
//   };
//   lifeRel();


//   Anonymous Function
// a function with no name 
// in this way only fun with function keyword only keep () paranthesis
// const NumLogs = function() {
// console.log(123);
// }
// NumLogs();

// An anonymous function can also be an argument of a function hence, it can be declared inside another function as its parameters. A simple example to illustrate is a native JavaScript function setTimeout:
// srt time out fun h jo automatically after 30 minutes chal jaiyga no neeed to call
// setTimeout(
//     function () {
//       console.log("Executed after three seconds");
//     }  , 3000 // delay in milliseconds
//   )
//   setTimeout(
//     function () {
//       console.log("Executed after 1 seconds");
//     }  , 1000 // delay in milliseconds
//   )
//   setTimeout(
//     function () {
//       console.log("Executed after 2 seconds");
//     }  , 2000 // delay in milliseconds
//   )


// Immediately Invoked Function Expressions iife


// (function () {
//     console.log("Welcome to Javascript");
//   })();

//   The trailing parentheses ( ) are used to invoke the function. 


// Constructor Functions


// Arrow Function
// This is a feature available in the ES6 version of JavaScript and as such has not stayed in the space for as long as the other features in the function declaration. It is generally a cleaner way of creating JavaScript functions and it is similar to the function expression.

// let sum = () => {
//     let result = "hiiiii"
//     return result;
// }

// let aall = sum()
// console.log(aall)
// Hello World

// without curly barkets
// in arrow roun barck pass a paramet
let ex = (x) => console.log(x)
ex("i am ex")
ex("i am ex")
ex("i am ex")
ex("i am ex")
ex("i am ex")

// For an expression without an argument, the parentheses are left empty:
let greet = () => console.log("Welcome to Javascript Arrow functions");
greet();

