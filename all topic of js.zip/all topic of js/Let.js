let z=60;
// let z=80;this will bring error bcz z has already been decalre

console.log(z);
