// array is used to store multiple values of same data type but in js we can store diff sata types values
// const cars = ["eng", "math", "sci"];
// console.log(cars);

// JavaScript Array concat()
// Returns array by merging given value and/or arrays

// let alphabets = ["A","B","C"]
// let numbers = [2, 4, 6, 8]

// // join two arrays 
// let conCatArray = alphabets.concat(numbers);
// console.log(conCatArray);

/* Output:
[
  'A', 'B', 'C', 2,
  4,   6,   8
]
*/

// JavaScript Array splice()
// Returns an array by changing its elements in place by adding any element or removing
// let prime_numbers = [2, 3, 5, 7, 9, 11];

// replace 1 element from index 4 by 13
// let removedElement = prime_numbers.splice(4, 1, 13);
// console.log(removedElement);
// console.log(prime_numbers);

// phly wo index num likhen gyh value chnge krni h maslan 4 index py agar chnge krni h value to 1 wrna zero or 3rd parameter m jo value chngr krni h wo likhen gyh

// Output: [ 9 ]
//         [ 2, 3, 5, 7, 13, 11 ]


// JavaScript Array lastIndexOf()
// Returns the last index of occurrence of an element
// let priceList = [10, 8, 2, 31, 10, 31, 65];

// finding the index of the last occurence of 31
// let lastIndex = priceList.lastIndexOf(65);

// console.log(lastIndex); 
// index find na hony par -1 return krta h lastindexof
// Output: 5

// JavaScript Array indexOf()
// Returns the first index of occurrence of element

// JavaScript Array of() Method
// Creates a new Array instance from given arguments

// JavaScript Array slice()
// Returns a shallow copy of a portion of an array

// JavaScript Array findIndex()
// Returns index of element that satisfies condition

// JavaScript Array find()
// Returns first element that satisfies a condition

// JavaScript Array includes()
// Checks if a value exists in an array

// Javascript Array reduceRight()
// Reduces array to single value from right to left

// Javascript Array reduce()
// Reduces array to single value from left to right

// Javascript Array isArray()
// Checks if the given value is a JavaScript Array

// Javascript Array filter()
// Returns array by filtering elements on given test

// The filter() method returns a new array with all elements that pass the test defined by the given function.
// const numbe = [1,2, 3,4, 5,6, 7, 8, 9,10];

// // function to check even numbers
// function chcNumberS(numbe) {
//   if (numbe % 2 == 0)
//   console.log("The Even Numbers are" +" " +numbe);
//   else if (numbe % 2 !=0) {
//     console.log("The Odd Numbers are" +" " +numbe); 
//   }
// }

// filter jo h wo apny under callback function h is lie wo ak func chenums call krha hai
// koi b function jo as a argument ksi dsry func ko pass kry call back fun khlata h
// arr.filter(callback(element), thisArg)
// create a new array by filter even numbers from the numbers array
// let chcNumber = numbe.filter(chcNumberS);


// console.log("The Odd Numbers are" +" " +oddNumS);

// JavaScript Array map()
// Returns array by mapping elements using given func
// The map() method creates a new array with the results of calling a function for every array element.
// har bar iterate kr k map sy array k sary elements ko call kryga
// map method b as a arumnt dsra fun accept krta h means call back func
// const digits = [4, 9, 16, 25];
// sqrsS= digits.map(Math.sqrt);
// console.log(sqrsS)
// console.log(digits)

// Javascript Array forEach()
// Executes the given function on array elements

// Javascript Array some()
// checks if any element passes given condition function
// find kren gyh k kiya koi condition k mutabki koi b element exsisit krta h k nhin
// a test function: returns an even number
// if condition fulfil to true ayega
function isEven(elementS) {
    return elementS % 2 === 0;
  }
  
  // defining an array
  let numbers = [1, 3, 2, 5, 4];
  
  // checks whether the numbers array contain at least one even number
  console.log(numbers.some(isEven));
//   agar koi b output exsist krhi hogi to resul true ayega

// Javascript Array every()
// Tests if all elements pass the given test function

// Javascript Array entries()
// Returns iterator containing key/value pair array

// JavaScript Array keys()
// Returns an iterator containing keys of array items

// JavaScript Array values()
// Returns iterator containing values of array items

// Javascript Array.from()
// Creates a new Array from array-like object

// Javascript Array constructor
// Returns the constructor function for the array

// Javascript Array copyWithin()
// Copies and overwrites elements within the array

// Javascript Array toLocaleString()
// Returns string representing the elements of array

// JavaScript Array flat()
// Flattens the nested array to given depth

// JavaScript Array flatMap()
// Returns new array by mapping and flattening array
