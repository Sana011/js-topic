const x=90;
// const x=50;this will bring error
console.log(x)