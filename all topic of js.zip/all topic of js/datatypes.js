// The five most basic types of data are strings, numbers, booleans, undefined, and null.
// These basic data types are also called primitives
// strings,Strings are collections of alphanumeric characters and symbols
let str ="11Hello world %%$##"
console.log(str);

// Null is similar to undefined, except it has to be set intentionally.empty or nothing,
let num =null;
console.log(num)

// undefined means empty or nothing in variable value is not defined or undefined exists when we haven’t given a value,
let undef;
console.log(undef)
// numbers
let numbe=123.888;
console.log(numbe)

// boolean true false bi result